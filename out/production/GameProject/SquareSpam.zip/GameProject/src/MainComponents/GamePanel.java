package MainComponents;

import Inputs.KeyboardInputs;
import Inputs.MouseInputs;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.Random;

public class GamePanel extends JPanel {

    private MouseInputs mouseInputs;
    private float xDelta = 100, yDelta = 100;
    private float xDirection = 1f, yDirection = 1f;
    private Color rectColor = new Color(150, 20, 90);
    private Random random;

    private ArrayList<MyRect> rects = new ArrayList<>();

    public GamePanel() {
        random = new Random();
        mouseInputs = new MouseInputs(this);
        addKeyListener(new KeyboardInputs(this));
        addMouseListener(mouseInputs);
        addMouseMotionListener(mouseInputs); // so we don't create 2 new objects, but rather one
    }

    public void changeXDelta(int value) {
        this.xDelta += value;
    }

    public void changeYDelta(int value) {
        this.yDelta += value;
    }

    public void setRectPosition(int x, int y) {
        this.xDelta = x;
        this.yDelta = y;
    }
    public void spawnRect(int x, int y) {
        rects.add(new MyRect(x, y));
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g); // does the JComponents paint method before I do stuff myself

        for (MyRect rect : rects) {
            rect.updateRect();
            rect.draw(g);
        }

        updateRectangle();
        g.setColor(rectColor);
        g.fillRect((int) xDelta, (int) yDelta, 200, 50);


    }

    public void updateRectangle() {
        xDelta += xDirection;
        if (xDelta > 400 || xDelta < 0) {
            xDirection = xDirection * -1;
            rectColor = getRandomColor();
        }

        yDelta += yDirection;
        if (yDelta > 400 || yDelta < 0) {
            yDirection = yDirection * -1;
            rectColor = getRandomColor();
        }
    }

    private Color getRandomColor() {
        int red = random.nextInt(255);
        int green = random.nextInt(255);
        int blue = random.nextInt(255);
        return new Color(red, blue, green);
    }

    public class MyRect {
        int x, y, w, h;
        int xDirection = 1, yDirection = 1;
        Color myColor;

        public MyRect(int x, int y) {
            this.x = x;
            this.y = y;
            w = random.nextInt(50);
            h = w;
            myColor = color();
        }

        private void updateRect() {
            this.x += xDirection;
            this.y += yDirection;

            if ((x + w) > 400 || x < 0) {
                xDirection *= -1;
                myColor = color();
            }
            if ((y + h) > 400 || x < 0) {
                yDirection *= -1;
                myColor = color();
            }
        }

        private Color color(){
            return new Color(random.nextInt(255),random.nextInt(255),random.nextInt(255));
        }

        public void draw(Graphics g){
            g.setColor(myColor);
            g.fillRect(x,y,w,h);
        }
    }
}
