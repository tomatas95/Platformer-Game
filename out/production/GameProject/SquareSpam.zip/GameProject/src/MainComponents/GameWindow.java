package MainComponents;

import javax.swing.*;

public class GameWindow extends JFrame {

    public GameWindow(GamePanel gamePanel){

    JFrame jframe = new JFrame();

    jframe.setSize(400,400);
    jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    jframe.add(gamePanel);
    jframe.setLocationRelativeTo(null); // Frame starts middle of the screen
    jframe.setVisible(true); //  should be in the bottom so when you open the program it doesn't appear to be only white screen for one frame

    }
}
