package MainComponents;

public class Game implements Runnable {
    private GameWindow gameWindow;
    private GamePanel gamePanel;
    private Thread gameThread;
    private final int FPS_SET = 120;

    public Game() {
        gamePanel = new GamePanel();
        gameWindow = new GameWindow(gamePanel);
        gamePanel.requestFocus(); // Input focus on the panel
        startGameLoop();

    }

    private void startGameLoop(){
        gameThread = new Thread(this);
        gameThread.start();
    }

    /**
     * When an object implementing interface {@code Runnable} is used
     * to create a thread, starting the thread causes the object's
     * {@code run} method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method {@code run} is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     */
    @Override
    // The more threads the better to avoid any traffic jam in our program to make it much more smoother.
    // Each Thread needs a certain runnable tasks to do, so they're both working interchangebly
    public void run() {

        double timePerFrame = 1000000000.0 / FPS_SET;// make this into nanoseconds
        long lastFrame = System.nanoTime();
        long current = System.nanoTime();

        int frames = 0;
        long lastCheck = System.currentTimeMillis();
        while (true) {
            current = System.nanoTime();
            if (current - lastFrame >= timePerFrame) {
                gamePanel.repaint();
                lastFrame = current;
                frames++;
            }
            if(System.currentTimeMillis() - lastCheck >= 1000) {
                lastCheck = System.currentTimeMillis();
                System.out.println("FPS: " + frames);
                frames = 0;
            }
        }
    }
}
